﻿using System;
using System.Collections.Generic;
using System.Transactions;
using System.Linq;

namespace Week6
{
    class Program
    {
        static void Main(string[] args)
        {

            Problem1();
            Console.WriteLine(" ");
            Console.WriteLine(" ");

            problem2();

            


        }

        static void Problem1()
        {
            List<string> list = new List<string>();

            string answer = "";
            bool a;


            do
            {
                Console.WriteLine("Please write in a name or Press enter to quit");
                answer = Console.ReadLine();
                // Console.WriteLine(answer);

                if (a = string.IsNullOrEmpty(answer))
                {


                    answer = "ok";
                }
                else
                {
                    list.Add(answer);
                }






            } while (answer != "ok");

            //list.RemoveAt(list.Count - 1);


            if (list.Count > 2)
            {
                //Console.WriteLine("contains ");
                Console.WriteLine(list[0] + ", " + list[1] + " and " + (list.Count - 2) + "  Others like your post.");

            }
            else if (list.Count == 2)
            {
                //Console.WriteLine("nothing here");
                Console.WriteLine(list[0] + ", " + list[1] + " Like your post.");
            }
            else if (list.Count == 1)
            {
                Console.WriteLine(list[0] + " Like your post.");
            }
            else
            {
                Console.WriteLine(" ");
            }


            Console.WriteLine("---------------------");
            Console.WriteLine("");
            //foreach(string n in list)
            //{

            //Console.WriteLine(n);
            //}

        }


        static void problem2()
        {

            Dictionary<char, int> answer = new Dictionary<char, int>();
            char[] sen;
            char hold;
            bool b;

            Console.WriteLine("Enter a sentence : ");

            string line = Console.ReadLine();


            foreach (char sent in line)
            {


                if (answer.ContainsKey(sent))
                {

                    answer[sent] += 1;





                }
                else
                {
                    answer[sent] = 1;
                }


            }

            foreach (KeyValuePair<char, int> pair in answer)
            {


                Console.WriteLine(pair.Key + " | " + pair.Value);

            }
        }
    }
}